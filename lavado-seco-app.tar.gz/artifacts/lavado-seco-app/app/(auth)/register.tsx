import { AppButton } from "@/components/AppButton";
import { AppInput } from "@/components/AppInput";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function RegisterScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { register } = useAuth();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleRegister() {
    if (!name.trim() || !email.trim() || !phone.trim() || !password || !confirm) {
      setError("Por favor completa todos los campos");
      return;
    }
    if (password !== confirm) {
      setError("Las contraseñas no coinciden");
      return;
    }
    if (password.length < 6) {
      setError("La contraseña debe tener al menos 6 caracteres");
      return;
    }
    setLoading(true);
    setError("");
    const ok = await register({ name: name.trim(), email: email.trim(), phone, password });
    setLoading(false);
    if (!ok) {
      setError("Este correo ya está registrado");
    } else {
      router.replace("/(tabs)/");
    }
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.navy }]}>
      <View
        style={[
          styles.topSection,
          { paddingTop: insets.top + (Platform.OS === "web" ? 24 : 0) },
        ]}
      >
        <Image
          source={require("@/assets/images/icon.png")}
          style={styles.logo}
          resizeMode="contain"
        />
        <Text style={styles.brand}>LavadoSeco</Text>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.flex}
      >
        <ScrollView
          contentContainerStyle={[
            styles.form,
            { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20) },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View
            style={[
              styles.card,
              { backgroundColor: colors.background, borderRadius: colors.radius + 4 },
            ]}
          >
            <TouchableOpacity
              onPress={() => router.back()}
              style={styles.backBtn}
            >
              <Feather name="arrow-left" size={20} color={colors.mutedForeground} />
            </TouchableOpacity>

            <Text style={[styles.title, { color: colors.foreground }]}>
              Crear Cuenta
            </Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Únete y empieza a disfrutar
            </Text>

            <AppInput
              label="Nombre completo"
              value={name}
              onChangeText={setName}
              leftIcon="user"
              placeholder="Juan Pérez"
              autoCapitalize="words"
            />
            <AppInput
              label="Correo electrónico"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              leftIcon="mail"
              placeholder="correo@ejemplo.com"
            />
            <AppInput
              label="Teléfono"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              leftIcon="phone"
              placeholder="300 000 0000"
            />
            <AppInput
              label="Contraseña"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPass}
              leftIcon="lock"
              rightIcon={showPass ? "eye-off" : "eye"}
              onRightIconPress={() => setShowPass((v) => !v)}
              placeholder="Mínimo 6 caracteres"
            />
            <AppInput
              label="Confirmar contraseña"
              value={confirm}
              onChangeText={setConfirm}
              secureTextEntry={!showPass}
              leftIcon="lock"
              placeholder="Repite tu contraseña"
            />

            {error ? (
              <View
                style={[styles.errorBox, { backgroundColor: colors.destructive + "18" }]}
              >
                <Feather name="alert-circle" size={14} color={colors.destructive} />
                <Text style={[styles.errorText, { color: colors.destructive }]}>
                  {error}
                </Text>
              </View>
            ) : null}

            <AppButton
              title="Crear Cuenta"
              onPress={handleRegister}
              loading={loading}
              style={{ marginTop: 8 }}
            />

            <TouchableOpacity
              onPress={() => router.back()}
              style={styles.loginLink}
            >
              <Text style={[styles.loginText, { color: colors.mutedForeground }]}>
                ¿Ya tienes cuenta?{" "}
                <Text style={{ color: colors.primary, fontFamily: "Inter_600SemiBold" }}>
                  Inicia sesión
                </Text>
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  flex: { flex: 1 },
  topSection: {
    alignItems: "center",
    paddingBottom: 24,
    paddingHorizontal: 24,
  },
  logo: { width: 60, height: 60, borderRadius: 14, marginTop: 12, marginBottom: 8 },
  brand: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    color: "#fff",
  },
  form: { paddingHorizontal: 20, paddingTop: 4 },
  card: {
    padding: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 8,
  },
  backBtn: { marginBottom: 16 },
  title: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    marginBottom: 24,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  errorText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  loginLink: {
    alignItems: "center",
    marginTop: 20,
    paddingVertical: 8,
  },
  loginText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
});

import { AppButton } from "@/components/AppButton";
import { AppInput } from "@/components/AppInput";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React, { useState } from "react";
import {
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function LoginScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { login } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleLogin() {
    if (!email.trim() || !password.trim()) {
      setError("Por favor completa todos los campos");
      return;
    }
    setLoading(true);
    setError("");
    const ok = await login(email.trim(), password);
    setLoading(false);
    if (!ok) {
      setError("Correo o contraseña incorrectos");
    } else {
      router.replace("/(tabs)/");
    }
  }

  return (
    <View style={[styles.root, { backgroundColor: colors.navy }]}>
      <View
        style={[
          styles.topSection,
          { paddingTop: insets.top + (Platform.OS === "web" ? 24 : 0) },
        ]}
      >
        <View style={styles.logoWrap}>
          <Image
            source={require("@/assets/images/icon.png")}
            style={styles.logo}
            resizeMode="contain"
          />
        </View>
        <Text style={styles.brand}>LavadoSeco</Text>
        <Text style={styles.tagline}>Limpieza profesional · Sin agua · A domicilio</Text>
      </View>

      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={styles.flex}
      >
        <ScrollView
          contentContainerStyle={[
            styles.form,
            {
              paddingBottom:
                insets.bottom + (Platform.OS === "web" ? 34 : 20),
            },
          ]}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <View
            style={[
              styles.card,
              {
                backgroundColor: colors.background,
                borderRadius: colors.radius + 4,
              },
            ]}
          >
            <Text style={[styles.title, { color: colors.foreground }]}>
              Iniciar Sesión
            </Text>
            <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>
              Bienvenido de nuevo
            </Text>

            <AppInput
              label="Correo electrónico"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
              leftIcon="mail"
              placeholder="correo@ejemplo.com"
            />
            <AppInput
              label="Contraseña"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
              leftIcon="lock"
              rightIcon={showPassword ? "eye-off" : "eye"}
              onRightIconPress={() => setShowPassword((v) => !v)}
              placeholder="Tu contraseña"
            />

            {error ? (
              <View
                style={[
                  styles.errorBox,
                  { backgroundColor: colors.destructive + "18" },
                ]}
              >
                <Feather name="alert-circle" size={14} color={colors.destructive} />
                <Text
                  style={[styles.errorText, { color: colors.destructive }]}
                >
                  {error}
                </Text>
              </View>
            ) : null}

            <AppButton
              title="Ingresar"
              onPress={handleLogin}
              loading={loading}
              style={{ marginTop: 8 }}
            />

            <TouchableOpacity
              onPress={() => router.push("/(auth)/register")}
              style={styles.registerLink}
            >
              <Text style={[styles.registerText, { color: colors.mutedForeground }]}>
                ¿No tienes cuenta?{" "}
                <Text style={{ color: colors.primary, fontFamily: "Inter_600SemiBold" }}>
                  Regístrate
                </Text>
              </Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  flex: { flex: 1 },
  topSection: {
    alignItems: "center",
    paddingHorizontal: 24,
    paddingBottom: 32,
  },
  logoWrap: {
    width: 80,
    height: 80,
    borderRadius: 20,
    overflow: "hidden",
    marginBottom: 12,
    marginTop: 20,
  },
  logo: { width: 80, height: 80 },
  brand: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    letterSpacing: -0.5,
  },
  tagline: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.6)",
    marginTop: 6,
    textAlign: "center",
  },
  form: {
    paddingHorizontal: 20,
    paddingTop: 8,
  },
  card: {
    padding: 24,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: -2 },
    shadowOpacity: 0.1,
    shadowRadius: 20,
    elevation: 8,
  },
  title: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    marginBottom: 24,
  },
  errorBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
  },
  errorText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  registerLink: {
    alignItems: "center",
    marginTop: 20,
    paddingVertical: 8,
  },
  registerText: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
  },
});

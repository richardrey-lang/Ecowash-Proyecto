import { AppButton } from "@/components/AppButton";
import { AppInput } from "@/components/AppInput";
import { BookingCard } from "@/components/BookingCard";
import { ServiceCard, Service } from "@/components/ServiceCard";
import { useAuth } from "@/context/AuthContext";
import { useBookings } from "@/context/BookingsContext";
import { useColors } from "@/hooks/useColors";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const SERVICES: Service[] = [
  {
    id: "1",
    name: "Lavado Básico en Seco",
    description: "Limpieza exterior completa con productos de calidad premium sin agua.",
    price: 50000,
    duration: "45 min",
    includes: ["Exterior completo", "Vidrios limpios", "Llantas brillantes"],
  },
  {
    id: "2",
    name: "Lavado Premium",
    description: "Incluye detallado interior y exterior con acabado protector.",
    price: 90000,
    duration: "90 min",
    includes: ["Todo el básico", "Interior detallado", "Tablero tratado", "Asientos limpios"],
    highlighted: true,
  },
  {
    id: "3",
    name: "Lavado Completo + Cera",
    description: "Servicio integral con cera protectora de larga duración para máximo brillo.",
    price: 130000,
    duration: "2 horas",
    includes: ["Todo el premium", "Cera protectora", "Puli-brillo", "Certificado calidad"],
  },
];

const TIMES = ["8:00 AM", "9:00 AM", "10:00 AM", "11:00 AM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"];

export default function ServiciosScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { createBooking, getUserBookings, cancelBooking } = useBookings();

  const [tab, setTab] = useState<"reservar" | "mis_reservas">("reservar");
  const [selectedService, setSelectedService] = useState<Service | null>(null);
  const [bookingModal, setBookingModal] = useState(false);
  const [address, setAddress] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [loading, setLoading] = useState(false);
  const [successModal, setSuccessModal] = useState(false);

  const myBookings = user ? getUserBookings(user.id) : [];

  function openBooking(service: Service) {
    setSelectedService(service);
    setBookingModal(true);
  }

  async function handleConfirmBooking() {
    if (!address.trim() || !date.trim() || !time || !vehicle.trim()) {
      Alert.alert("Campos requeridos", "Por favor completa todos los campos");
      return;
    }
    if (!user || !selectedService) return;
    setLoading(true);
    await createBooking({
      userId: user.id,
      serviceId: selectedService.id,
      serviceName: selectedService.name,
      servicePrice: selectedService.price,
      vehicle: vehicle.trim(),
      address: address.trim(),
      date: date.trim(),
      time,
    });
    setLoading(false);
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setBookingModal(false);
    setSuccessModal(true);
    setAddress("");
    setDate("");
    setTime("");
    setVehicle("");
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header */}
      <View
        style={[
          styles.header,
          {
            backgroundColor: colors.navy,
            paddingTop: topPad + 16,
            paddingBottom: 0,
          },
        ]}
      >
        <Text style={styles.headerTitle}>Servicios</Text>
        <Text style={styles.headerSub}>Lavado a domicilio · Sin agua</Text>
        <View style={[styles.tabs, { backgroundColor: "rgba(255,255,255,0.12)" }]}>
          {(["reservar", "mis_reservas"] as const).map((t) => (
            <TouchableOpacity
              key={t}
              onPress={() => setTab(t)}
              style={[
                styles.tabItem,
                tab === t && { backgroundColor: colors.primary, borderRadius: 8 },
              ]}
            >
              <Text
                style={[
                  styles.tabText,
                  { color: tab === t ? "#fff" : "rgba(255,255,255,0.6)" },
                ]}
              >
                {t === "reservar" ? "Reservar" : "Mis Reservas"}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.content,
          { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20) + 80 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {tab === "reservar" ? (
          <>
            <Text style={[styles.sectionDesc, { color: colors.mutedForeground }]}>
              Selecciona el servicio que necesitas y agendamos un técnico en tu dirección.
            </Text>
            {SERVICES.map((s) => (
              <ServiceCard key={s.id} service={s} onSelect={() => openBooking(s)} />
            ))}
          </>
        ) : (
          <>
            {myBookings.length === 0 ? (
              <View style={styles.empty}>
                <Text style={[styles.emptyTitle, { color: colors.foreground }]}>
                  Sin reservas aún
                </Text>
                <Text style={[styles.emptyDesc, { color: colors.mutedForeground }]}>
                  Reserva tu primer lavado en seco a domicilio
                </Text>
                <AppButton
                  title="Reservar ahora"
                  onPress={() => setTab("reservar")}
                  style={{ marginTop: 16, alignSelf: "center" }}
                  fullWidth={false}
                />
              </View>
            ) : (
              myBookings.map((b) => (
                <BookingCard
                  key={b.id}
                  booking={b}
                  onCancel={() => cancelBooking(b.id)}
                />
              ))
            )}
          </>
        )}
      </ScrollView>

      {/* Booking Modal */}
      <Modal visible={bookingModal} animationType="slide" presentationStyle="pageSheet">
        <ScrollView
          style={{ flex: 1, backgroundColor: colors.background }}
          contentContainerStyle={[
            styles.modalContent,
            { paddingBottom: insets.bottom + 20 },
          ]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.modalHandle} />
          <Text style={[styles.modalTitle, { color: colors.foreground }]}>
            Reservar Servicio
          </Text>
          <View
            style={[
              styles.serviceInfo,
              { backgroundColor: colors.secondary, borderRadius: colors.radius },
            ]}
          >
            <Text style={[styles.serviceInfoName, { color: colors.primary }]}>
              {selectedService?.name}
            </Text>
            <Text style={[styles.serviceInfoPrice, { color: colors.foreground }]}>
              ${selectedService?.price.toLocaleString("es-CO")}
            </Text>
          </View>
          <AppInput
            label="Vehículo (marca, modelo, color)"
            value={vehicle}
            onChangeText={setVehicle}
            leftIcon="truck"
            placeholder="Toyota Corolla Azul"
          />
          <AppInput
            label="Dirección"
            value={address}
            onChangeText={setAddress}
            leftIcon="map-pin"
            placeholder="Calle 123 #45-67, Bogotá"
          />
          <AppInput
            label="Fecha (dd/mm/aaaa)"
            value={date}
            onChangeText={setDate}
            leftIcon="calendar"
            placeholder="15/06/2026"
            keyboardType="numeric"
          />
          <Text style={[styles.timeLabel, { color: colors.mutedForeground }]}>
            Hora preferida
          </Text>
          <View style={styles.timeGrid}>
            {TIMES.map((t) => (
              <TouchableOpacity
                key={t}
                onPress={() => setTime(t)}
                style={[
                  styles.timeChip,
                  {
                    backgroundColor:
                      time === t ? colors.primary : colors.secondary,
                    borderRadius: colors.radius - 4,
                  },
                ]}
              >
                <Text
                  style={[
                    styles.timeChipText,
                    { color: time === t ? "#fff" : colors.foreground },
                  ]}
                >
                  {t}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
          <AppButton
            title="Confirmar Reserva"
            onPress={handleConfirmBooking}
            loading={loading}
            style={{ marginTop: 16 }}
          />
          <AppButton
            title="Cancelar"
            variant="ghost"
            onPress={() => setBookingModal(false)}
            style={{ marginTop: 8 }}
          />
        </ScrollView>
      </Modal>

      {/* Success Modal */}
      <Modal visible={successModal} animationType="fade" transparent>
        <View style={styles.successOverlay}>
          <View
            style={[
              styles.successCard,
              { backgroundColor: colors.card, borderRadius: colors.radius + 4 },
            ]}
          >
            <View style={[styles.successIcon, { backgroundColor: colors.success + "20" }]}>
              <Text style={{ fontSize: 40 }}>✓</Text>
            </View>
            <Text style={[styles.successTitle, { color: colors.foreground }]}>
              ¡Reserva Confirmada!
            </Text>
            <Text style={[styles.successDesc, { color: colors.mutedForeground }]}>
              Un técnico llegará a tu dirección en el horario indicado.
            </Text>
            <AppButton
              title="Ver mis reservas"
              onPress={() => {
                setSuccessModal(false);
                setTab("mis_reservas");
              }}
              style={{ marginTop: 16 }}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 26,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    marginBottom: 4,
  },
  headerSub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.6)",
    marginBottom: 16,
  },
  tabs: {
    flexDirection: "row",
    borderRadius: 10,
    padding: 4,
    marginBottom: 16,
  },
  tabItem: {
    flex: 1,
    paddingVertical: 8,
    alignItems: "center",
  },
  tabText: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
  },
  content: { padding: 16 },
  sectionDesc: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    lineHeight: 20,
    marginBottom: 16,
  },
  empty: { alignItems: "center", paddingVertical: 60 },
  emptyTitle: {
    fontSize: 18,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 8,
  },
  emptyDesc: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  modalContent: { padding: 20 },
  modalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#ddd",
    alignSelf: "center",
    marginBottom: 20,
  },
  modalTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    marginBottom: 16,
  },
  serviceInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 14,
    marginBottom: 16,
  },
  serviceInfoName: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    flex: 1,
  },
  serviceInfoPrice: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
  },
  timeLabel: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    marginBottom: 8,
  },
  timeGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 8,
    marginBottom: 8,
  },
  timeChip: {
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  timeChipText: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  successOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  successCard: {
    width: "100%",
    padding: 28,
    alignItems: "center",
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  successTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    marginBottom: 8,
  },
  successDesc: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
});

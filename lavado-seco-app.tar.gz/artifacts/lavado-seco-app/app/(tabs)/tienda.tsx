import { AppButton } from "@/components/AppButton";
import { ProductCard, Product } from "@/components/ProductCard";
import { useCart } from "@/context/CartContext";
import { useColors } from "@/hooks/useColors";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  FlatList,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const ALL_PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "Spray Lavado Seco Premium",
    description: "Fórmula avanzada para limpieza sin agua. 500ml.",
    price: 35000,
    category: "Lavado Seco",
  },
  {
    id: "p2",
    name: "Microfibra Profesional Ultra",
    description: "Paño de microfibra 600gsm para acabados perfectos.",
    price: 25000,
    category: "Accesorios",
  },
  {
    id: "p3",
    name: "Kit Lavado Seco Completo",
    description: "Spray + 3 microfibras + aplicador de cera. Todo incluido.",
    price: 85000,
    category: "Kits",
  },
  {
    id: "p4",
    name: "Cera Protectora UV",
    description: "Protección UV de larga duración. Brillo espejo.",
    price: 55000,
    category: "Protección",
  },
  {
    id: "p5",
    name: "Limpia Vidrios Pro",
    description: "Sin rayas, sin residuos. Visibilidad perfecta.",
    price: 20000,
    category: "Vidrios",
  },
  {
    id: "p6",
    name: "Detallador Interior",
    description: "Limpia y protege tablero, plásticos y cuero.",
    price: 45000,
    category: "Interior",
  },
  {
    id: "p7",
    name: "Renovador de Llantas",
    description: "Brillo intenso y protección para llantas.",
    price: 28000,
    category: "Llantas",
  },
  {
    id: "p8",
    name: "Desengrasante Motor",
    description: "Limpieza profunda de motor y compartimento.",
    price: 38000,
    category: "Motor",
  },
];

const CATEGORIES = ["Todos", "Lavado Seco", "Kits", "Accesorios", "Protección", "Interior", "Vidrios", "Llantas", "Motor"];

export default function TiendaScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { items, addItem, updateQuantity, removeItem, total, count, clearCart } = useCart();

  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [cartModal, setCartModal] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);

  const filtered =
    selectedCategory === "Todos"
      ? ALL_PRODUCTS
      : ALL_PRODUCTS.filter((p) => p.category === selectedCategory);

  function getCartItem(productId: string) {
    return items.find((i) => i.productId === productId);
  }

  function handleAddToCart(product: Product) {
    addItem({ productId: product.id, name: product.name, price: product.price });
  }

  function handleOrder() {
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    clearCart();
    setCartModal(false);
    setOrderSuccess(true);
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      {/* Header */}
      <View
        style={[
          styles.header,
          { backgroundColor: colors.navy, paddingTop: topPad + 16 },
        ]}
      >
        <View style={styles.headerRow}>
          <View>
            <Text style={styles.headerTitle}>Tienda</Text>
            <Text style={styles.headerSub}>Productos de lavado en seco</Text>
          </View>
          <TouchableOpacity
            onPress={() => setCartModal(true)}
            style={[styles.cartBtn, { backgroundColor: colors.primary }]}
          >
            <Feather name="shopping-cart" size={20} color="#fff" />
            {count > 0 && (
              <View style={[styles.badge, { backgroundColor: colors.destructive }]}>
                <Text style={styles.badgeText}>{count}</Text>
              </View>
            )}
          </TouchableOpacity>
        </View>

        {/* Categories */}
        <FlatList
          data={CATEGORIES}
          horizontal
          showsHorizontalScrollIndicator={false}
          keyExtractor={(i) => i}
          contentContainerStyle={{ gap: 8, paddingBottom: 16, paddingHorizontal: 0 }}
          renderItem={({ item }) => (
            <TouchableOpacity
              onPress={() => setSelectedCategory(item)}
              style={[
                styles.catChip,
                {
                  backgroundColor:
                    selectedCategory === item
                      ? colors.primary
                      : "rgba(255,255,255,0.12)",
                  borderRadius: 20,
                },
              ]}
            >
              <Text
                style={[
                  styles.catText,
                  { color: selectedCategory === item ? "#fff" : "rgba(255,255,255,0.7)" },
                ]}
              >
                {item}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      <ScrollView
        contentContainerStyle={[
          styles.grid,
          { paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20) + 80 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.productsGrid}>
          {filtered.map((product) => {
            const cartItem = getCartItem(product.id);
            return (
              <ProductCard
                key={product.id}
                product={{ ...product, inCart: !!cartItem, cartQty: cartItem?.quantity }}
                onAddToCart={() => handleAddToCart(product)}
                onIncrement={() =>
                  cartItem && updateQuantity(product.id, cartItem.quantity + 1)
                }
                onDecrement={() =>
                  cartItem && updateQuantity(product.id, cartItem.quantity - 1)
                }
              />
            );
          })}
        </View>
      </ScrollView>

      {/* Cart Modal */}
      <Modal visible={cartModal} animationType="slide" presentationStyle="pageSheet">
        <View style={{ flex: 1, backgroundColor: colors.background }}>
          <View style={[styles.modalHeader, { paddingTop: 20 }]}>
            <View style={styles.modalHandle} />
            <View style={styles.modalTitleRow}>
              <Text style={[styles.modalTitle, { color: colors.foreground }]}>
                Carrito
              </Text>
              <TouchableOpacity onPress={() => setCartModal(false)}>
                <Feather name="x" size={22} color={colors.mutedForeground} />
              </TouchableOpacity>
            </View>
          </View>
          {items.length === 0 ? (
            <View style={styles.emptyCart}>
              <Feather name="shopping-cart" size={48} color={colors.mutedForeground} />
              <Text style={[styles.emptyCartText, { color: colors.mutedForeground }]}>
                Tu carrito está vacío
              </Text>
            </View>
          ) : (
            <>
              <ScrollView contentContainerStyle={{ padding: 16 }}>
                {items.map((item) => (
                  <View
                    key={item.id}
                    style={[
                      styles.cartItem,
                      { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
                    ]}
                  >
                    <View style={styles.cartItemInfo}>
                      <Text style={[styles.cartItemName, { color: colors.foreground }]}>
                        {item.name}
                      </Text>
                      <Text style={[styles.cartItemPrice, { color: colors.primary }]}>
                        ${item.price.toLocaleString("es-CO")}
                      </Text>
                    </View>
                    <View style={styles.cartItemActions}>
                      <TouchableOpacity
                        onPress={() => updateQuantity(item.productId, item.quantity - 1)}
                        style={[styles.qtyBtn, { backgroundColor: colors.secondary }]}
                      >
                        <Feather name="minus" size={14} color={colors.primary} />
                      </TouchableOpacity>
                      <Text style={[styles.qtyText, { color: colors.foreground }]}>
                        {item.quantity}
                      </Text>
                      <TouchableOpacity
                        onPress={() => updateQuantity(item.productId, item.quantity + 1)}
                        style={[styles.qtyBtn, { backgroundColor: colors.primary }]}
                      >
                        <Feather name="plus" size={14} color="#fff" />
                      </TouchableOpacity>
                      <TouchableOpacity
                        onPress={() => removeItem(item.productId)}
                        style={{ marginLeft: 8 }}
                      >
                        <Feather name="trash-2" size={16} color={colors.destructive} />
                      </TouchableOpacity>
                    </View>
                  </View>
                ))}
              </ScrollView>
              <View
                style={[
                  styles.cartFooter,
                  {
                    borderTopColor: colors.border,
                    paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 8),
                  },
                ]}
              >
                <View style={styles.totalRow}>
                  <Text style={[styles.totalLabel, { color: colors.mutedForeground }]}>
                    Total
                  </Text>
                  <Text style={[styles.totalAmount, { color: colors.foreground }]}>
                    ${total.toLocaleString("es-CO")}
                  </Text>
                </View>
                <AppButton title="Realizar Pedido" onPress={handleOrder} />
              </View>
            </>
          )}
        </View>
      </Modal>

      {/* Order success modal */}
      <Modal visible={orderSuccess} animationType="fade" transparent>
        <View style={styles.successOverlay}>
          <View
            style={[
              styles.successCard,
              { backgroundColor: colors.card, borderRadius: colors.radius + 4 },
            ]}
          >
            <View style={[styles.successIcon, { backgroundColor: colors.success + "20" }]}>
              <Text style={{ fontSize: 40 }}>✓</Text>
            </View>
            <Text style={[styles.successTitle, { color: colors.foreground }]}>
              ¡Pedido Enviado!
            </Text>
            <Text style={[styles.successDesc, { color: colors.mutedForeground }]}>
              Tu pedido fue recibido. Te contactaremos para coordinar la entrega.
            </Text>
            <AppButton
              title="Continuar comprando"
              onPress={() => setOrderSuccess(false)}
              style={{ marginTop: 16 }}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
  },
  headerRow: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    marginBottom: 14,
  },
  headerTitle: {
    fontSize: 26,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    marginBottom: 2,
  },
  headerSub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.6)",
  },
  cartBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  badge: {
    position: "absolute",
    top: -4,
    right: -4,
    width: 18,
    height: 18,
    borderRadius: 9,
    alignItems: "center",
    justifyContent: "center",
  },
  badgeText: {
    color: "#fff",
    fontSize: 10,
    fontFamily: "Inter_700Bold",
  },
  catChip: {
    paddingHorizontal: 14,
    paddingVertical: 7,
  },
  catText: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  grid: { padding: 16 },
  productsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 12,
    justifyContent: "space-between",
  },
  modalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#ddd",
    alignSelf: "center",
    marginBottom: 12,
  },
  modalHeader: { paddingHorizontal: 20 },
  modalTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 4,
  },
  modalTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
  },
  emptyCart: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    gap: 12,
  },
  emptyCartText: {
    fontSize: 16,
    fontFamily: "Inter_400Regular",
  },
  cartItem: {
    padding: 14,
    marginBottom: 10,
    borderWidth: 1,
  },
  cartItemInfo: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 10,
  },
  cartItemName: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
    flex: 1,
    marginRight: 8,
  },
  cartItemPrice: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
  },
  cartItemActions: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  qtyBtn: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: "center",
    justifyContent: "center",
  },
  qtyText: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    minWidth: 24,
    textAlign: "center",
  },
  cartFooter: {
    padding: 16,
    borderTopWidth: 1,
  },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 16,
  },
  totalLabel: {
    fontSize: 15,
    fontFamily: "Inter_500Medium",
  },
  totalAmount: {
    fontSize: 24,
    fontFamily: "Inter_700Bold",
  },
  successOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  successCard: {
    width: "100%",
    padding: 28,
    alignItems: "center",
  },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  successTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    marginBottom: 8,
  },
  successDesc: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
});

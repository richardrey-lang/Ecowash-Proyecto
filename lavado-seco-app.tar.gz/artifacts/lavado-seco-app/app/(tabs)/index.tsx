import { BookingCard } from "@/components/BookingCard";
import { useAuth } from "@/context/AuthContext";
import { useBookings } from "@/context/BookingsContext";
import { useColors } from "@/hooks/useColors";
import { Feather } from "@expo/vector-icons";
import { router } from "expo-router";
import React from "react";
import {
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const FEATURES = [
  {
    icon: "droplet" as const,
    title: "Sin agua",
    desc: "Lavado ecológico",
  },
  {
    icon: "truck" as const,
    title: "A domicilio",
    desc: "Vamos a tu casa",
  },
  {
    icon: "star" as const,
    title: "Profesional",
    desc: "Técnicos certificados",
  },
];

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, logout } = useAuth();
  const { getUserBookings, cancelBooking } = useBookings();

  const recentBookings = user ? getUserBookings(user.id).slice(0, 2) : [];

  const topPad =
    Platform.OS === "web" ? 67 : insets.top;

  return (
    <ScrollView
      style={{ backgroundColor: colors.background }}
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{ paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20) + 80 }}
    >
      {/* Header */}
      <View
        style={[
          styles.header,
          { backgroundColor: colors.navy, paddingTop: topPad + 16 },
        ]}
      >
        <View>
          <Text style={styles.greeting}>Hola, {user?.name?.split(" ")[0]} 👋</Text>
          <Text style={styles.headerSub}>¿Listo para un lavado profesional?</Text>
        </View>
        <TouchableOpacity onPress={logout} style={styles.logoutBtn}>
          <Feather name="log-out" size={20} color="rgba(255,255,255,0.7)" />
        </TouchableOpacity>
      </View>

      {/* Hero card */}
      <View style={[styles.heroCard, { backgroundColor: colors.navy }]}>
        <Image
          source={require("@/assets/images/hero_service.png")}
          style={styles.heroImage}
          resizeMode="cover"
        />
        <View style={styles.heroOverlay}>
          <Text style={styles.heroTitle}>Lavado en Seco{"\n"}Profesional</Text>
          <Text style={styles.heroSub}>Cuidamos tu vehículo sin usar agua</Text>
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/servicios")}
            style={[styles.heroBtn, { backgroundColor: colors.primary }]}
          >
            <Text style={styles.heroBtnText}>Reservar Ahora</Text>
            <Feather name="arrow-right" size={16} color="#fff" />
          </TouchableOpacity>
        </View>
      </View>

      {/* Features */}
      <View style={styles.featuresRow}>
        {FEATURES.map((f) => (
          <View
            key={f.title}
            style={[
              styles.featureItem,
              { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
            ]}
          >
            <View
              style={[styles.featureIcon, { backgroundColor: colors.secondary }]}
            >
              <Feather name={f.icon} size={20} color={colors.primary} />
            </View>
            <Text style={[styles.featureTitle, { color: colors.foreground }]}>
              {f.title}
            </Text>
            <Text style={[styles.featureDesc, { color: colors.mutedForeground }]}>
              {f.desc}
            </Text>
          </View>
        ))}
      </View>

      {/* Quick actions */}
      <View style={styles.section}>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
          Acciones Rápidas
        </Text>
        <View style={styles.actionsGrid}>
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/servicios")}
            style={[
              styles.actionCard,
              { backgroundColor: colors.primary, borderRadius: colors.radius },
            ]}
          >
            <Feather name="calendar" size={24} color="#fff" />
            <Text style={styles.actionTextWhite}>Reservar{"\n"}Servicio</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/tienda")}
            style={[
              styles.actionCard,
              { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderRadius: colors.radius },
            ]}
          >
            <Feather name="shopping-bag" size={24} color={colors.primary} />
            <Text style={[styles.actionTextPrimary, { color: colors.foreground }]}>
              Tienda{"\n"}Productos
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/soporte")}
            style={[
              styles.actionCard,
              { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderRadius: colors.radius },
            ]}
          >
            <Feather name="headphones" size={24} color={colors.primary} />
            <Text style={[styles.actionTextPrimary, { color: colors.foreground }]}>
              Soporte{"\n"}24/7
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => router.push("/(tabs)/perfil")}
            style={[
              styles.actionCard,
              { backgroundColor: colors.card, borderColor: colors.border, borderWidth: 1, borderRadius: colors.radius },
            ]}
          >
            <Feather name="user" size={24} color={colors.primary} />
            <Text style={[styles.actionTextPrimary, { color: colors.foreground }]}>
              Mi{"\n"}Perfil
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Recent bookings */}
      {recentBookings.length > 0 && (
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Mis Reservas Recientes
            </Text>
            <TouchableOpacity onPress={() => router.push("/(tabs)/servicios")}>
              <Text style={[styles.seeAll, { color: colors.primary }]}>Ver todo</Text>
            </TouchableOpacity>
          </View>
          {recentBookings.map((b) => (
            <BookingCard
              key={b.id}
              booking={b}
              onCancel={() => cancelBooking(b.id)}
            />
          ))}
        </View>
      )}

      {/* Promo banner */}
      <View
        style={[
          styles.promoBanner,
          { backgroundColor: colors.accent + "20", borderColor: colors.accent + "40", borderRadius: colors.radius },
        ]}
      >
        <Feather name="zap" size={20} color={colors.primary} />
        <View style={{ flex: 1 }}>
          <Text style={[styles.promoTitle, { color: colors.foreground }]}>
            Primera reserva con descuento
          </Text>
          <Text style={[styles.promoDesc, { color: colors.mutedForeground }]}>
            Obtén 20% de descuento en tu primer lavado en seco a domicilio
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    paddingHorizontal: 20,
    paddingBottom: 0,
  },
  greeting: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    marginBottom: 2,
  },
  headerSub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.6)",
    marginBottom: 20,
  },
  logoutBtn: { padding: 8 },
  heroCard: { overflow: "hidden" },
  heroImage: { width: "100%", height: 200 },
  heroOverlay: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    backgroundColor: "rgba(10,22,40,0.7)",
  },
  heroTitle: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    marginBottom: 4,
  },
  heroSub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.75)",
    marginBottom: 12,
  },
  heroBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    alignSelf: "flex-start",
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 20,
  },
  heroBtnText: {
    color: "#fff",
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
  },
  featuresRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    paddingTop: 16,
    gap: 10,
  },
  featureItem: {
    flex: 1,
    alignItems: "center",
    padding: 12,
    borderWidth: 1,
  },
  featureIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 8,
  },
  featureTitle: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 2,
    textAlign: "center",
  },
  featureDesc: {
    fontSize: 11,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
  },
  section: { paddingHorizontal: 16, marginTop: 24 },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    marginBottom: 12,
  },
  seeAll: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
  actionsGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 10,
  },
  actionCard: {
    width: "47%",
    padding: 16,
    alignItems: "flex-start",
    gap: 10,
  },
  actionTextWhite: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    color: "#fff",
    lineHeight: 20,
  },
  actionTextPrimary: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    lineHeight: 20,
  },
  promoBanner: {
    margin: 16,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    borderWidth: 1,
    marginTop: 24,
  },
  promoTitle: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 3,
  },
  promoDesc: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    lineHeight: 17,
  },
});

import { AppButton } from "@/components/AppButton";
import { AppInput } from "@/components/AppInput";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Linking,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

const FAQS = [
  {
    q: "¿Cuánto tarda el servicio de lavado en seco?",
    a: "Dependiendo del servicio, entre 45 minutos y 2 horas. El técnico te confirmará el tiempo exacto al llegar.",
  },
  {
    q: "¿Es seguro el lavado en seco para mi vehículo?",
    a: "Sí, completamente. Nuestros productos son especialmente formulados para no dañar la pintura ni los materiales.",
  },
  {
    q: "¿Cuál es el área de cobertura?",
    a: "Cubrimos toda la ciudad y alrededores. Al hacer tu reserva, confirmaremos si llegamos a tu zona.",
  },
  {
    q: "¿Puedo cancelar una reserva?",
    a: "Sí, puedes cancelar hasta 2 horas antes del servicio sin costo desde la sección 'Mis Reservas'.",
  },
  {
    q: "¿Los productos son ecológicos?",
    a: "Sí, todos nuestros productos son biodegradables y no contaminantes. Ahorramos hasta 200 litros de agua por lavado.",
  },
  {
    q: "¿Cómo hago el pago?",
    a: "El pago se realiza al finalizar el servicio en efectivo o transferencia bancaria.",
  },
];

const CONTACT_OPTIONS = [
  {
    icon: "phone" as const,
    label: "Llamar",
    value: "+57 300 000 0000",
    action: () => Linking.openURL("tel:+573000000000"),
  },
  {
    icon: "message-circle" as const,
    label: "WhatsApp",
    value: "Respuesta inmediata",
    action: () => Linking.openURL("https://wa.me/573000000000"),
  },
  {
    icon: "mail" as const,
    label: "Email",
    value: "soporte@lavadoseco.co",
    action: () => Linking.openURL("mailto:soporte@lavadoseco.co"),
  },
];

export default function SoporteScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);
  const [ticketModal, setTicketModal] = useState(false);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [successModal, setSuccessModal] = useState(false);

  async function handleSendTicket() {
    if (!subject.trim() || !message.trim()) {
      Alert.alert("Campos requeridos", "Por favor completa asunto y mensaje");
      return;
    }
    setLoading(true);
    await new Promise((r) => setTimeout(r, 1200));
    setLoading(false);
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setTicketModal(false);
    setSuccessModal(true);
    setSubject("");
    setMessage("");
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20) + 80,
        }}
      >
        {/* Header */}
        <View
          style={[
            styles.header,
            { backgroundColor: colors.navy, paddingTop: topPad + 16 },
          ]}
        >
          <Text style={styles.headerTitle}>Soporte</Text>
          <Text style={styles.headerSub}>Estamos aquí para ayudarte</Text>
          <View
            style={[
              styles.availableBadge,
              { backgroundColor: colors.success + "30" },
            ]}
          >
            <View style={[styles.dot, { backgroundColor: colors.success }]} />
            <Text style={[styles.availableText, { color: colors.success }]}>
              Disponible 24/7
            </Text>
          </View>
        </View>

        {/* Contact options */}
        <View style={[styles.section, { marginTop: 20 }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Contáctanos
          </Text>
          {CONTACT_OPTIONS.map((opt) => (
            <TouchableOpacity
              key={opt.label}
              onPress={opt.action}
              style={[
                styles.contactCard,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <View
                style={[styles.contactIcon, { backgroundColor: colors.secondary }]}
              >
                <Feather name={opt.icon} size={20} color={colors.primary} />
              </View>
              <View style={styles.contactInfo}>
                <Text style={[styles.contactLabel, { color: colors.foreground }]}>
                  {opt.label}
                </Text>
                <Text style={[styles.contactValue, { color: colors.mutedForeground }]}>
                  {opt.value}
                </Text>
              </View>
              <Feather name="chevron-right" size={18} color={colors.mutedForeground} />
            </TouchableOpacity>
          ))}
        </View>

        {/* Open ticket */}
        <View style={styles.section}>
          <View
            style={[
              styles.ticketCard,
              {
                backgroundColor: colors.primary + "12",
                borderColor: colors.primary + "30",
                borderRadius: colors.radius,
              },
            ]}
          >
            <Feather name="inbox" size={28} color={colors.primary} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.ticketTitle, { color: colors.foreground }]}>
                Abrir Ticket de Soporte
              </Text>
              <Text style={[styles.ticketDesc, { color: colors.mutedForeground }]}>
                Describe tu problema y te respondemos en menos de 24 horas
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => setTicketModal(true)}
              style={[styles.ticketBtn, { backgroundColor: colors.primary }]}
            >
              <Feather name="plus" size={16} color="#fff" />
            </TouchableOpacity>
          </View>
        </View>

        {/* FAQ */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Preguntas Frecuentes
          </Text>
          {FAQS.map((faq, i) => (
            <TouchableOpacity
              key={i}
              onPress={() => setExpandedFaq(expandedFaq === i ? null : i)}
              style={[
                styles.faqItem,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <View style={styles.faqHeader}>
                <Text
                  style={[styles.faqQuestion, { color: colors.foreground, flex: 1 }]}
                >
                  {faq.q}
                </Text>
                <Feather
                  name={expandedFaq === i ? "chevron-up" : "chevron-down"}
                  size={16}
                  color={colors.mutedForeground}
                />
              </View>
              {expandedFaq === i && (
                <Text style={[styles.faqAnswer, { color: colors.mutedForeground }]}>
                  {faq.a}
                </Text>
              )}
            </TouchableOpacity>
          ))}
        </View>

        {/* About */}
        <View
          style={[
            styles.aboutCard,
            { backgroundColor: colors.navy, borderRadius: colors.radius, margin: 16 },
          ]}
        >
          <Text style={styles.aboutTitle}>LavadoSeco Pro</Text>
          <Text style={styles.aboutDesc}>
            Servicio profesional de lavado en seco a domicilio. Cuidamos tu vehículo
            con los mejores productos del mercado, sin usar agua.
          </Text>
          <View style={styles.aboutStats}>
            {[
              { value: "5000+", label: "Clientes" },
              { value: "98%", label: "Satisfacción" },
              { value: "0L", label: "Agua usada" },
            ].map((s) => (
              <View key={s.label} style={styles.stat}>
                <Text style={styles.statValue}>{s.value}</Text>
                <Text style={styles.statLabel}>{s.label}</Text>
              </View>
            ))}
          </View>
        </View>
      </ScrollView>

      {/* Ticket Modal */}
      <Modal visible={ticketModal} animationType="slide" presentationStyle="pageSheet">
        <ScrollView
          style={{ flex: 1, backgroundColor: colors.background }}
          contentContainerStyle={[
            styles.modalContent,
            { paddingBottom: insets.bottom + 20 },
          ]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.modalHandle} />
          <View style={styles.modalTitleRow}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>
              Nuevo Ticket
            </Text>
            <TouchableOpacity onPress={() => setTicketModal(false)}>
              <Feather name="x" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
          {user && (
            <View
              style={[
                styles.userInfo,
                { backgroundColor: colors.secondary, borderRadius: colors.radius },
              ]}
            >
              <Feather name="user" size={14} color={colors.primary} />
              <Text style={[styles.userInfoText, { color: colors.mutedForeground }]}>
                {user.name} · {user.email}
              </Text>
            </View>
          )}
          <AppInput
            label="Asunto"
            value={subject}
            onChangeText={setSubject}
            leftIcon="edit-2"
            placeholder="Ej: Problema con mi reserva"
          />
          <View style={styles.textAreaWrap}>
            <Text style={[styles.textAreaLabel, { color: colors.mutedForeground }]}>
              Descripción
            </Text>
            <View
              style={[
                styles.textArea,
                { borderColor: colors.border, borderRadius: colors.radius, backgroundColor: colors.card },
              ]}
            >
              <AppInput
                value={message}
                onChangeText={setMessage}
                multiline
                numberOfLines={5}
                placeholder="Describe tu problema con el mayor detalle posible..."
                style={{ minHeight: 100, textAlignVertical: "top" }}
              />
            </View>
          </View>
          <AppButton
            title="Enviar Ticket"
            onPress={handleSendTicket}
            loading={loading}
            style={{ marginTop: 8 }}
          />
          <AppButton
            title="Cancelar"
            variant="ghost"
            onPress={() => setTicketModal(false)}
            style={{ marginTop: 8 }}
          />
        </ScrollView>
      </Modal>

      {/* Success */}
      <Modal visible={successModal} animationType="fade" transparent>
        <View style={styles.successOverlay}>
          <View
            style={[
              styles.successCard,
              { backgroundColor: colors.card, borderRadius: colors.radius + 4 },
            ]}
          >
            <View style={[styles.successIcon, { backgroundColor: colors.success + "20" }]}>
              <Text style={{ fontSize: 40 }}>✓</Text>
            </View>
            <Text style={[styles.successTitle, { color: colors.foreground }]}>
              ¡Ticket Enviado!
            </Text>
            <Text style={[styles.successDesc, { color: colors.mutedForeground }]}>
              Te responderemos en menos de 24 horas al correo registrado.
            </Text>
            <AppButton
              title="Aceptar"
              onPress={() => setSuccessModal(false)}
              style={{ marginTop: 16 }}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  headerTitle: {
    fontSize: 26,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    marginBottom: 4,
  },
  headerSub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.6)",
    marginBottom: 12,
  },
  availableBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    alignSelf: "flex-start",
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 20,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  availableText: { fontSize: 12, fontFamily: "Inter_600SemiBold" },
  section: { paddingHorizontal: 16, marginBottom: 8 },
  sectionTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    marginBottom: 12,
  },
  contactCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    gap: 12,
  },
  contactIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  contactInfo: { flex: 1 },
  contactLabel: { fontSize: 15, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  contactValue: { fontSize: 12, fontFamily: "Inter_400Regular" },
  ticketCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderWidth: 1,
    gap: 12,
    marginBottom: 16,
  },
  ticketTitle: { fontSize: 15, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  ticketDesc: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 17 },
  ticketBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  faqItem: {
    padding: 14,
    borderWidth: 1,
    marginBottom: 8,
  },
  faqHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  faqQuestion: { fontSize: 14, fontFamily: "Inter_500Medium", lineHeight: 20 },
  faqAnswer: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 19,
    marginTop: 10,
  },
  aboutCard: { padding: 20 },
  aboutTitle: {
    fontSize: 18,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    marginBottom: 8,
  },
  aboutDesc: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.7)",
    lineHeight: 19,
    marginBottom: 16,
  },
  aboutStats: { flexDirection: "row", gap: 24 },
  stat: { alignItems: "center" },
  statValue: { fontSize: 20, fontFamily: "Inter_700Bold", color: "#fff" },
  statLabel: { fontSize: 11, fontFamily: "Inter_400Regular", color: "rgba(255,255,255,0.6)" },
  modalContent: { padding: 20 },
  modalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: "#ddd",
    alignSelf: "center",
    marginBottom: 20,
  },
  modalTitleRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 16,
  },
  modalTitle: { fontSize: 22, fontFamily: "Inter_700Bold" },
  userInfo: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    padding: 12,
    marginBottom: 16,
  },
  userInfoText: { fontSize: 13, fontFamily: "Inter_400Regular" },
  textAreaWrap: { marginBottom: 8 },
  textAreaLabel: { fontSize: 13, fontFamily: "Inter_500Medium", marginBottom: 6 },
  textArea: { overflow: "hidden" },
  successOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  successCard: { width: "100%", padding: 28, alignItems: "center" },
  successIcon: {
    width: 80,
    height: 80,
    borderRadius: 40,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
  },
  successTitle: { fontSize: 22, fontFamily: "Inter_700Bold", marginBottom: 8 },
  successDesc: {
    fontSize: 14,
    fontFamily: "Inter_400Regular",
    textAlign: "center",
    lineHeight: 20,
  },
});

import { AppButton } from "@/components/AppButton";
import { AppInput } from "@/components/AppInput";
import { useAuth } from "@/context/AuthContext";
import { useColors } from "@/hooks/useColors";
import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  Modal,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

export default function PerfilScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { user, logout, updateUser, addVehicle } = useAuth();

  const [editModal, setEditModal] = useState(false);
  const [vehicleModal, setVehicleModal] = useState(false);
  const [name, setName] = useState(user?.name ?? "");
  const [phone, setPhone] = useState(user?.phone ?? "");
  const [vBrand, setVBrand] = useState("");
  const [vModel, setVModel] = useState("");
  const [vPlate, setVPlate] = useState("");
  const [vColor, setVColor] = useState("");
  const [saving, setSaving] = useState(false);

  async function handleSaveProfile() {
    if (!name.trim()) return;
    setSaving(true);
    await updateUser({ name: name.trim(), phone: phone.trim() });
    setSaving(false);
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setEditModal(false);
  }

  async function handleAddVehicle() {
    if (!vBrand.trim() || !vModel.trim() || !vPlate.trim() || !vColor.trim()) {
      Alert.alert("Campos requeridos", "Completa todos los datos del vehículo");
      return;
    }
    setSaving(true);
    await addVehicle({ brand: vBrand.trim(), model: vModel.trim(), plate: vPlate.toUpperCase().trim(), color: vColor.trim() });
    setSaving(false);
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setVehicleModal(false);
    setVBrand(""); setVModel(""); setVPlate(""); setVColor("");
  }

  const topPad = Platform.OS === "web" ? 67 : insets.top;

  const initials = user?.name
    .split(" ")
    .map((n) => n[0])
    .slice(0, 2)
    .join("")
    .toUpperCase() ?? "U";

  return (
    <View style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingBottom: insets.bottom + (Platform.OS === "web" ? 34 : 20) + 80,
        }}
      >
        {/* Header */}
        <View
          style={[
            styles.header,
            { backgroundColor: colors.navy, paddingTop: topPad + 20, paddingBottom: 24 },
          ]}
        >
          <View style={[styles.avatar, { backgroundColor: colors.primary }]}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          <Text style={styles.headerName}>{user?.name}</Text>
          <Text style={styles.headerEmail}>{user?.email}</Text>
          <TouchableOpacity
            onPress={() => {
              setName(user?.name ?? "");
              setPhone(user?.phone ?? "");
              setEditModal(true);
            }}
            style={[styles.editBtn, { backgroundColor: "rgba(255,255,255,0.15)" }]}
          >
            <Feather name="edit-2" size={14} color="#fff" />
            <Text style={styles.editBtnText}>Editar perfil</Text>
          </TouchableOpacity>
        </View>

        {/* Info cards */}
        <View style={[styles.section, { marginTop: 20 }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
            Información Personal
          </Text>
          {[
            { icon: "user" as const, label: "Nombre", value: user?.name },
            { icon: "mail" as const, label: "Correo", value: user?.email },
            { icon: "phone" as const, label: "Teléfono", value: user?.phone || "No registrado" },
          ].map((item) => (
            <View
              key={item.label}
              style={[
                styles.infoCard,
                { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
              ]}
            >
              <View style={[styles.infoIcon, { backgroundColor: colors.secondary }]}>
                <Feather name={item.icon} size={16} color={colors.primary} />
              </View>
              <View>
                <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>
                  {item.label}
                </Text>
                <Text style={[styles.infoValue, { color: colors.foreground }]}>
                  {item.value}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* Vehicles */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
              Mis Vehículos
            </Text>
            <TouchableOpacity
              onPress={() => setVehicleModal(true)}
              style={[styles.addVehicleBtn, { backgroundColor: colors.primary }]}
            >
              <Feather name="plus" size={14} color="#fff" />
              <Text style={styles.addVehicleBtnText}>Agregar</Text>
            </TouchableOpacity>
          </View>

          {user?.vehicles.length === 0 && (
            <View
              style={[
                styles.emptyVehicle,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <Feather name="truck" size={32} color={colors.mutedForeground} />
              <Text style={[styles.emptyVehicleText, { color: colors.mutedForeground }]}>
                No tienes vehículos registrados
              </Text>
              <TouchableOpacity onPress={() => setVehicleModal(true)}>
                <Text style={[styles.addVehicleLink, { color: colors.primary }]}>
                  + Agregar vehículo
                </Text>
              </TouchableOpacity>
            </View>
          )}

          {user?.vehicles.map((v) => (
            <View
              key={v.id}
              style={[
                styles.vehicleCard,
                {
                  backgroundColor: colors.card,
                  borderColor: colors.border,
                  borderRadius: colors.radius,
                },
              ]}
            >
              <View style={[styles.vehicleIcon, { backgroundColor: colors.secondary }]}>
                <Feather name="truck" size={20} color={colors.primary} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.vehicleName, { color: colors.foreground }]}>
                  {v.brand} {v.model}
                </Text>
                <Text style={[styles.vehicleDetail, { color: colors.mutedForeground }]}>
                  {v.plate} · {v.color}
                </Text>
              </View>
            </View>
          ))}
        </View>

        {/* Logout */}
        <View style={[styles.section, { marginTop: 8 }]}>
          <AppButton
            title="Cerrar Sesión"
            variant="destructive"
            onPress={() =>
              Alert.alert("Cerrar Sesión", "¿Seguro que deseas salir?", [
                { text: "Cancelar", style: "cancel" },
                { text: "Salir", style: "destructive", onPress: logout },
              ])
            }
          />
        </View>
      </ScrollView>

      {/* Edit Profile Modal */}
      <Modal visible={editModal} animationType="slide" presentationStyle="formSheet">
        <ScrollView
          style={{ flex: 1, backgroundColor: colors.background }}
          contentContainerStyle={[styles.modalContent, { paddingBottom: insets.bottom + 20 }]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.modalHandle} />
          <View style={styles.modalTitleRow}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>
              Editar Perfil
            </Text>
            <TouchableOpacity onPress={() => setEditModal(false)}>
              <Feather name="x" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
          <AppInput
            label="Nombre completo"
            value={name}
            onChangeText={setName}
            leftIcon="user"
            autoCapitalize="words"
          />
          <AppInput
            label="Teléfono"
            value={phone}
            onChangeText={setPhone}
            leftIcon="phone"
            keyboardType="phone-pad"
          />
          <AppButton
            title="Guardar cambios"
            onPress={handleSaveProfile}
            loading={saving}
            style={{ marginTop: 8 }}
          />
          <AppButton
            title="Cancelar"
            variant="ghost"
            onPress={() => setEditModal(false)}
            style={{ marginTop: 8 }}
          />
        </ScrollView>
      </Modal>

      {/* Add Vehicle Modal */}
      <Modal visible={vehicleModal} animationType="slide" presentationStyle="formSheet">
        <ScrollView
          style={{ flex: 1, backgroundColor: colors.background }}
          contentContainerStyle={[styles.modalContent, { paddingBottom: insets.bottom + 20 }]}
          keyboardShouldPersistTaps="handled"
        >
          <View style={styles.modalHandle} />
          <View style={styles.modalTitleRow}>
            <Text style={[styles.modalTitle, { color: colors.foreground }]}>
              Agregar Vehículo
            </Text>
            <TouchableOpacity onPress={() => setVehicleModal(false)}>
              <Feather name="x" size={22} color={colors.mutedForeground} />
            </TouchableOpacity>
          </View>
          <AppInput label="Marca" value={vBrand} onChangeText={setVBrand} leftIcon="truck" placeholder="Toyota" autoCapitalize="words" />
          <AppInput label="Modelo" value={vModel} onChangeText={setVModel} leftIcon="settings" placeholder="Corolla 2022" autoCapitalize="words" />
          <AppInput label="Placa" value={vPlate} onChangeText={setVPlate} leftIcon="hash" placeholder="ABC 123" autoCapitalize="characters" />
          <AppInput label="Color" value={vColor} onChangeText={setVColor} leftIcon="droplet" placeholder="Azul metálico" autoCapitalize="words" />
          <AppButton title="Agregar Vehículo" onPress={handleAddVehicle} loading={saving} style={{ marginTop: 8 }} />
          <AppButton title="Cancelar" variant="ghost" onPress={() => setVehicleModal(false)} style={{ marginTop: 8 }} />
        </ScrollView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    alignItems: "center",
    paddingHorizontal: 20,
  },
  avatar: {
    width: 76,
    height: 76,
    borderRadius: 38,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 12,
  },
  avatarText: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
    color: "#fff",
  },
  headerName: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    color: "#fff",
    marginBottom: 4,
  },
  headerEmail: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: "rgba(255,255,255,0.6)",
    marginBottom: 14,
  },
  editBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
  },
  editBtnText: {
    color: "#fff",
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
  section: { paddingHorizontal: 16, marginBottom: 8 },
  sectionHeader: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: 17,
    fontFamily: "Inter_700Bold",
    marginBottom: 12,
  },
  infoCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    marginBottom: 8,
    borderWidth: 1,
    gap: 12,
  },
  infoIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
  },
  infoLabel: { fontSize: 11, fontFamily: "Inter_400Regular", marginBottom: 2 },
  infoValue: { fontSize: 14, fontFamily: "Inter_500Medium" },
  addVehicleBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  addVehicleBtnText: { color: "#fff", fontSize: 12, fontFamily: "Inter_600SemiBold" },
  emptyVehicle: {
    alignItems: "center",
    padding: 28,
    borderWidth: 1,
    gap: 8,
  },
  emptyVehicleText: { fontSize: 14, fontFamily: "Inter_400Regular" },
  addVehicleLink: { fontSize: 14, fontFamily: "Inter_600SemiBold" },
  vehicleCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderWidth: 1,
    gap: 12,
    marginBottom: 8,
  },
  vehicleIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  vehicleName: { fontSize: 15, fontFamily: "Inter_600SemiBold", marginBottom: 2 },
  vehicleDetail: { fontSize: 12, fontFamily: "Inter_400Regular" },
  modalContent: { padding: 20 },
  modalHandle: {
    width: 40, height: 4, borderRadius: 2,
    backgroundColor: "#ddd", alignSelf: "center", marginBottom: 20,
  },
  modalTitleRow: {
    flexDirection: "row", alignItems: "center",
    justifyContent: "space-between", marginBottom: 20,
  },
  modalTitle: { fontSize: 22, fontFamily: "Inter_700Bold" },
});

const colors = {
  light: {
    text: "#0A1628",
    tint: "#1E6FDB",

    background: "#F5F8FF",
    foreground: "#0A1628",

    card: "#FFFFFF",
    cardForeground: "#0A1628",

    primary: "#1E6FDB",
    primaryForeground: "#FFFFFF",

    secondary: "#EBF2FF",
    secondaryForeground: "#1E6FDB",

    muted: "#F0F4FF",
    mutedForeground: "#6B7A99",

    accent: "#4DA6FF",
    accentForeground: "#FFFFFF",

    destructive: "#EF4444",
    destructiveForeground: "#FFFFFF",

    border: "#DDE6F5",
    input: "#DDE6F5",

    success: "#10B981",
    successForeground: "#FFFFFF",

    warning: "#F59E0B",
    warningForeground: "#FFFFFF",

    navy: "#0A1628",
    navyLight: "#162240",
  },

  radius: 12,
};

export default colors;

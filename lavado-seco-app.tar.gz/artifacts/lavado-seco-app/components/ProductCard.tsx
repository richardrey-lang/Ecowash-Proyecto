import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React from "react";
import {
  Image,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

import { useColors } from "@/hooks/useColors";

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image?: any;
  inCart?: boolean;
  cartQty?: number;
}

interface ProductCardProps {
  product: Product;
  onAddToCart: () => void;
  onIncrement?: () => void;
  onDecrement?: () => void;
}

export function ProductCard({
  product,
  onAddToCart,
  onIncrement,
  onDecrement,
}: ProductCardProps) {
  const colors = useColors();

  function handleAdd() {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    onAddToCart();
  }

  return (
    <View
      style={[
        styles.card,
        {
          backgroundColor: colors.card,
          borderRadius: colors.radius,
          borderColor: colors.border,
        },
      ]}
    >
      {product.image && (
        <Image source={product.image} style={styles.image} resizeMode="cover" />
      )}
      {!product.image && (
        <View
          style={[
            styles.imagePlaceholder,
            { backgroundColor: colors.secondary },
          ]}
        >
          <Feather name="droplet" size={32} color={colors.primary} />
        </View>
      )}
      <View style={styles.content}>
        <Text
          style={[styles.category, { color: colors.primary }]}
          numberOfLines={1}
        >
          {product.category}
        </Text>
        <Text
          style={[styles.name, { color: colors.foreground }]}
          numberOfLines={2}
        >
          {product.name}
        </Text>
        <Text style={[styles.desc, { color: colors.mutedForeground }]} numberOfLines={2}>
          {product.description}
        </Text>
        <View style={styles.footer}>
          <Text style={[styles.price, { color: colors.foreground }]}>
            ${product.price.toLocaleString("es-CO")}
          </Text>
          {product.inCart && product.cartQty ? (
            <View style={styles.qtyRow}>
              <TouchableOpacity
                onPress={onDecrement}
                style={[styles.qtyBtn, { backgroundColor: colors.secondary }]}
              >
                <Feather name="minus" size={14} color={colors.primary} />
              </TouchableOpacity>
              <Text style={[styles.qtyText, { color: colors.foreground }]}>
                {product.cartQty}
              </Text>
              <TouchableOpacity
                onPress={onIncrement}
                style={[styles.qtyBtn, { backgroundColor: colors.primary }]}
              >
                <Feather name="plus" size={14} color="#fff" />
              </TouchableOpacity>
            </View>
          ) : (
            <TouchableOpacity
              onPress={handleAdd}
              style={[
                styles.addBtn,
                { backgroundColor: colors.primary, borderRadius: colors.radius - 4 },
              ]}
            >
              <Feather name="shopping-cart" size={14} color="#fff" />
              <Text style={styles.addBtnText}>Agregar</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    width: 180,
    borderWidth: 1,
    overflow: "hidden",
    marginRight: 12,
  },
  image: { width: "100%", height: 120 },
  imagePlaceholder: {
    width: "100%",
    height: 120,
    alignItems: "center",
    justifyContent: "center",
  },
  content: { padding: 12 },
  category: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
    textTransform: "uppercase",
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  name: {
    fontSize: 14,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 4,
    lineHeight: 20,
  },
  desc: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
    marginBottom: 10,
    lineHeight: 17,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  price: {
    fontSize: 15,
    fontFamily: "Inter_700Bold",
  },
  addBtn: {
    flexDirection: "row",
    alignItems: "center",
    paddingHorizontal: 10,
    paddingVertical: 6,
    gap: 4,
  },
  addBtnText: {
    color: "#fff",
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
  qtyRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  qtyBtn: {
    width: 28,
    height: 28,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  qtyText: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    minWidth: 20,
    textAlign: "center",
  },
});

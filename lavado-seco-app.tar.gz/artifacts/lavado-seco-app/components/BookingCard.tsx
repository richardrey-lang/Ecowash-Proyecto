import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { Booking, BookingStatus } from "@/context/BookingsContext";
import { useColors } from "@/hooks/useColors";

interface BookingCardProps {
  booking: Booking;
  onCancel?: () => void;
}

const STATUS_LABELS: Record<BookingStatus, string> = {
  pendiente: "Pendiente",
  confirmado: "Confirmado",
  en_camino: "En Camino",
  completado: "Completado",
  cancelado: "Cancelado",
};

export function BookingCard({ booking, onCancel }: BookingCardProps) {
  const colors = useColors();

  const statusColor =
    booking.status === "completado"
      ? colors.success
      : booking.status === "cancelado"
      ? colors.destructive
      : booking.status === "en_camino"
      ? colors.accent
      : colors.primary;

  return (
    <View
      style={[
        styles.card,
        { backgroundColor: colors.card, borderColor: colors.border, borderRadius: colors.radius },
      ]}
    >
      <View style={styles.header}>
        <Text style={[styles.service, { color: colors.foreground }]} numberOfLines={1}>
          {booking.serviceName}
        </Text>
        <View style={[styles.statusBadge, { backgroundColor: statusColor + "20" }]}>
          <Text style={[styles.statusText, { color: statusColor }]}>
            {STATUS_LABELS[booking.status]}
          </Text>
        </View>
      </View>

      <View style={styles.detail}>
        <Feather name="truck" size={14} color={colors.mutedForeground} />
        <Text style={[styles.detailText, { color: colors.mutedForeground }]}>
          {booking.vehicle}
        </Text>
      </View>
      <View style={styles.detail}>
        <Feather name="map-pin" size={14} color={colors.mutedForeground} />
        <Text style={[styles.detailText, { color: colors.mutedForeground }]} numberOfLines={1}>
          {booking.address}
        </Text>
      </View>
      <View style={styles.detail}>
        <Feather name="calendar" size={14} color={colors.mutedForeground} />
        <Text style={[styles.detailText, { color: colors.mutedForeground }]}>
          {booking.date} · {booking.time}
        </Text>
      </View>

      <View style={styles.footer}>
        <Text style={[styles.price, { color: colors.foreground }]}>
          ${booking.servicePrice.toLocaleString("es-CO")}
        </Text>
        {(booking.status === "pendiente" || booking.status === "confirmado") && onCancel && (
          <TouchableOpacity
            onPress={onCancel}
            style={[styles.cancelBtn, { borderColor: colors.destructive }]}
          >
            <Text style={[styles.cancelText, { color: colors.destructive }]}>Cancelar</Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1,
    padding: 14,
    marginBottom: 10,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 10,
  },
  service: {
    fontSize: 15,
    fontFamily: "Inter_600SemiBold",
    flex: 1,
    marginRight: 8,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  detail: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 5,
  },
  detailText: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    flex: 1,
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginTop: 10,
  },
  price: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
  },
  cancelBtn: {
    borderWidth: 1,
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
  },
  cancelText: {
    fontSize: 12,
    fontFamily: "Inter_600SemiBold",
  },
});

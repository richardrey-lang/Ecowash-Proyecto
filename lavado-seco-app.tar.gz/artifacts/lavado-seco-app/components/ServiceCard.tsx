import { Feather } from "@expo/vector-icons";
import React from "react";
import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { useColors } from "@/hooks/useColors";

export interface Service {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string;
  includes: string[];
  highlighted?: boolean;
}

interface ServiceCardProps {
  service: Service;
  onSelect: () => void;
}

export function ServiceCard({ service, onSelect }: ServiceCardProps) {
  const colors = useColors();

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={onSelect}
      style={[
        styles.card,
        {
          backgroundColor: service.highlighted ? colors.navy : colors.card,
          borderColor: service.highlighted ? colors.primary : colors.border,
          borderRadius: colors.radius,
        },
      ]}
    >
      {service.highlighted && (
        <View style={[styles.badge, { backgroundColor: colors.primary }]}>
          <Text style={styles.badgeText}>Popular</Text>
        </View>
      )}
      <View style={styles.header}>
        <View
          style={[
            styles.iconWrap,
            {
              backgroundColor: service.highlighted
                ? "rgba(30,111,219,0.3)"
                : colors.secondary,
            },
          ]}
        >
          <Feather
            name="droplet"
            size={22}
            color={service.highlighted ? colors.accent : colors.primary}
          />
        </View>
        <View style={styles.headerText}>
          <Text
            style={[
              styles.name,
              { color: service.highlighted ? "#fff" : colors.foreground },
            ]}
          >
            {service.name}
          </Text>
          <Text
            style={[
              styles.duration,
              {
                color: service.highlighted
                  ? "rgba(255,255,255,0.6)"
                  : colors.mutedForeground,
              },
            ]}
          >
            {service.duration}
          </Text>
        </View>
      </View>
      <Text
        style={[
          styles.description,
          {
            color: service.highlighted
              ? "rgba(255,255,255,0.75)"
              : colors.mutedForeground,
          },
        ]}
        numberOfLines={2}
      >
        {service.description}
      </Text>
      <View style={styles.includes}>
        {service.includes.map((item) => (
          <View key={item} style={styles.includeRow}>
            <Feather
              name="check"
              size={13}
              color={service.highlighted ? colors.accent : colors.success}
            />
            <Text
              style={[
                styles.includeText,
                {
                  color: service.highlighted
                    ? "rgba(255,255,255,0.8)"
                    : colors.mutedForeground,
                },
              ]}
            >
              {item}
            </Text>
          </View>
        ))}
      </View>
      <View style={styles.footer}>
        <Text
          style={[
            styles.price,
            { color: service.highlighted ? "#fff" : colors.foreground },
          ]}
        >
          ${service.price.toLocaleString("es-CO")}
        </Text>
        <View
          style={[
            styles.selectBtn,
            { backgroundColor: service.highlighted ? colors.primary : colors.secondary },
          ]}
        >
          <Text
            style={[
              styles.selectText,
              { color: service.highlighted ? "#fff" : colors.primary },
            ]}
          >
            Seleccionar
          </Text>
          <Feather
            name="arrow-right"
            size={14}
            color={service.highlighted ? "#fff" : colors.primary}
          />
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  card: {
    borderWidth: 1.5,
    padding: 16,
    marginBottom: 12,
    overflow: "hidden",
  },
  badge: {
    position: "absolute",
    top: 12,
    right: 12,
    paddingHorizontal: 10,
    paddingVertical: 3,
    borderRadius: 20,
  },
  badgeText: {
    color: "#fff",
    fontSize: 11,
    fontFamily: "Inter_600SemiBold",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 10,
    gap: 12,
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
  },
  headerText: { flex: 1 },
  name: {
    fontSize: 16,
    fontFamily: "Inter_600SemiBold",
    marginBottom: 2,
  },
  duration: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  description: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    lineHeight: 19,
    marginBottom: 12,
  },
  includes: { gap: 6, marginBottom: 16 },
  includeRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  includeText: {
    fontSize: 12,
    fontFamily: "Inter_400Regular",
  },
  footer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
  },
  price: {
    fontSize: 22,
    fontFamily: "Inter_700Bold",
  },
  selectBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
  },
  selectText: {
    fontSize: 13,
    fontFamily: "Inter_600SemiBold",
  },
});

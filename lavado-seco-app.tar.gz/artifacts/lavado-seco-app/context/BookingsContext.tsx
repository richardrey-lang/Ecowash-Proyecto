import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

export type BookingStatus = "pendiente" | "confirmado" | "en_camino" | "completado" | "cancelado";

export interface Booking {
  id: string;
  userId: string;
  serviceId: string;
  serviceName: string;
  servicePrice: number;
  vehicle: string;
  address: string;
  date: string;
  time: string;
  status: BookingStatus;
  createdAt: string;
}

interface BookingsContextType {
  bookings: Booking[];
  createBooking: (data: Omit<Booking, "id" | "createdAt" | "status">) => Promise<Booking>;
  cancelBooking: (id: string) => Promise<void>;
  getUserBookings: (userId: string) => Booking[];
}

const BookingsContext = createContext<BookingsContextType | null>(null);
const BOOKINGS_KEY = "@lavado_bookings";

export function BookingsProvider({ children }: { children: React.ReactNode }) {
  const [bookings, setBookings] = useState<Booking[]>([]);

  useEffect(() => {
    AsyncStorage.getItem(BOOKINGS_KEY).then((stored) => {
      if (stored) setBookings(JSON.parse(stored));
    });
  }, []);

  async function persist(newBookings: Booking[]) {
    setBookings(newBookings);
    await AsyncStorage.setItem(BOOKINGS_KEY, JSON.stringify(newBookings));
  }

  async function createBooking(
    data: Omit<Booking, "id" | "createdAt" | "status">
  ): Promise<Booking> {
    const booking: Booking = {
      ...data,
      id: Date.now().toString(),
      status: "pendiente",
      createdAt: new Date().toISOString(),
    };
    await persist([...bookings, booking]);
    return booking;
  }

  async function cancelBooking(id: string) {
    await persist(
      bookings.map((b) => (b.id === id ? { ...b, status: "cancelado" as BookingStatus } : b))
    );
  }

  function getUserBookings(userId: string): Booking[] {
    return bookings
      .filter((b) => b.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  return (
    <BookingsContext.Provider
      value={{ bookings, createBooking, cancelBooking, getUserBookings }}
    >
      {children}
    </BookingsContext.Provider>
  );
}

export function useBookings() {
  const ctx = useContext(BookingsContext);
  if (!ctx) throw new Error("useBookings must be used within BookingsProvider");
  return ctx;
}

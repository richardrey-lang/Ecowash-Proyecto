import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useContext, useEffect, useState } from "react";

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  vehicles: Vehicle[];
}

export interface Vehicle {
  id: string;
  brand: string;
  model: string;
  plate: string;
  color: string;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (data: RegisterData) => Promise<boolean>;
  logout: () => Promise<void>;
  updateUser: (data: Partial<User>) => Promise<void>;
  addVehicle: (vehicle: Omit<Vehicle, "id">) => Promise<void>;
}

interface RegisterData {
  name: string;
  email: string;
  password: string;
  phone: string;
}

const AuthContext = createContext<AuthContextType | null>(null);

const USERS_KEY = "@lavado_users";
const CURRENT_USER_KEY = "@lavado_current_user";

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCurrentUser();
  }, []);

  async function loadCurrentUser() {
    try {
      const stored = await AsyncStorage.getItem(CURRENT_USER_KEY);
      if (stored) {
        setUser(JSON.parse(stored));
      }
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  }

  async function login(email: string, password: string): Promise<boolean> {
    try {
      const stored = await AsyncStorage.getItem(USERS_KEY);
      const users: Array<User & { password: string }> = stored
        ? JSON.parse(stored)
        : [];
      const found = users.find(
        (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
      );
      if (!found) return false;
      const { password: _, ...userData } = found;
      setUser(userData);
      await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userData));
      return true;
    } catch {
      return false;
    }
  }

  async function register(data: RegisterData): Promise<boolean> {
    try {
      const stored = await AsyncStorage.getItem(USERS_KEY);
      const users: Array<User & { password: string }> = stored
        ? JSON.parse(stored)
        : [];
      if (users.find((u) => u.email.toLowerCase() === data.email.toLowerCase())) {
        return false;
      }
      const newUser: User & { password: string } = {
        id: Date.now().toString(),
        name: data.name,
        email: data.email,
        phone: data.phone,
        vehicles: [],
        password: data.password,
      };
      users.push(newUser);
      await AsyncStorage.setItem(USERS_KEY, JSON.stringify(users));
      const { password: _, ...userData } = newUser;
      setUser(userData);
      await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userData));
      return true;
    } catch {
      return false;
    }
  }

  async function logout() {
    setUser(null);
    await AsyncStorage.removeItem(CURRENT_USER_KEY);
  }

  async function updateUser(data: Partial<User>) {
    if (!user) return;
    const updated = { ...user, ...data };
    setUser(updated);
    await AsyncStorage.setItem(CURRENT_USER_KEY, JSON.stringify(updated));
    const stored = await AsyncStorage.getItem(USERS_KEY);
    if (stored) {
      const users: Array<User & { password: string }> = JSON.parse(stored);
      const idx = users.findIndex((u) => u.id === user.id);
      if (idx >= 0) {
        users[idx] = { ...users[idx], ...data };
        await AsyncStorage.setItem(USERS_KEY, JSON.stringify(users));
      }
    }
  }

  async function addVehicle(vehicle: Omit<Vehicle, "id">) {
    if (!user) return;
    const newVehicle: Vehicle = { ...vehicle, id: Date.now().toString() };
    const updated = { ...user, vehicles: [...user.vehicles, newVehicle] };
    await updateUser(updated);
  }

  return (
    <AuthContext.Provider
      value={{ user, loading, login, register, logout, updateUser, addVehicle }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
